# Tender / Listing Crawler — 3-Hour Trial Pack

One command, no setup beyond Python 3.10+ (standard library only).

```
unzip crawl_trial_pack.zip && cd crawl_trial_pack
python trial.py                       # bundled 12-page sample site
python trial.py --dir your_pages      # your pages: list.html + detail html files
python trial.py --url https://site/list   # your live public list page
```

## What it does

| step | behaviour |
|---|---|
| 1. list page | collects detail links, resolves relative URLs, drops duplicate links |
| 2. detail fetch | retries 3× with backoff 0.4 / 0.8 / 1.6 s; a dead link goes to `failed`, never kills the batch |
| 3. field extraction | 8 fields: notice_type, title, project, buyer, region, publish_time, deadline, budget_yuan (万元 auto-converted to 元) |
| 4. dedupe | fingerprint = title + buyer + budget, normalised — repeat notices for the same tender collapse to one row |
| 5. ledger | `trial_out.xlsx` with 3 sheets: `tenders`, `failed`, `fill_rate` |

## Reference output (bundled sample, measured)

```
VERDICT 1 / scale : 1 list page -> 12 detail links -> 10 rows stored, 1 duplicate, 1 dead link
VERDICT 2 / risk  : fill_rate title 1.00 buyer 1.00 region 1.00 notice_type 1.00
                    deadline 0.90 publish_time 0.90 budget_yuan 0.90
VERDICT 3 / speed : 2.17 s, ledger trial_out.xlsx
```

## Three rules I will not break

1. **A missing field is written as missing, never as 0.** Two rows in the sample carry no budget / no publish time; they stay blank so you can see the site's real fill rate before paying for a full run.
2. **A dead page is reported, not hidden.** The 404 link lands in the `failed` sheet with its URL and reason; the other 10 rows still ship.
3. **Public pages only, 1 request per second.** No login state, no captcha bypass, no scraping of personal data. If a site needs a login, I tell you instead of working around it.

## Sizing / price

- ≤ 1 site, ≤ 200 detail pages: **$50 fixed**, 3-hour turnaround on the first batch so you can check the fill-rate sheet before committing.
- Each additional site with a different template: **+$10**.
- Ongoing scheduled runs (daily/weekly refresh with change detection): quoted per month after the first batch.

## Why the fill-rate sheet matters

Before you pay for 10,000 rows, look at `fill_rate`: if `deadline` is 0.40 on that site, the data is only 40% usable and the honest answer is "scrape a different source" — not a bigger bill.
