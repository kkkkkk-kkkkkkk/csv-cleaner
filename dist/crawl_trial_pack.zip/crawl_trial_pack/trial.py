#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""三秒试单：一条命令跑通「列表页 -> 详情页 -> 字段抽取 -> 判重 -> 台账」。

用法
    python trial.py                         # 自带 1 个列表页 + 4 个详情页样例（离线）
    python trial.py --dir your_pages        # 你的页面：同目录放 list.html 与详情 html
    python trial.py --url https://xxx/list  # 直接给你的真实列表页（公开页、1 秒 1 次）

输出
    三行 VERDICT（抓了几条 / 填充率 / 耗时）+ trial_out.xlsx（tenders / failed / fill_rate 三页）
"""
import os
import sys
import time
import argparse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import crawler


def _live_fetch(url):
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (compatible; tender-trial/1.0)",
        "Accept-Language": "zh-CN,zh;q=0.9",
    })
    with urllib.request.urlopen(req, timeout=15) as r:
        raw = r.read()
    for enc in ("utf-8", "gb18030"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "ignore")


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default=os.path.join(HERE, "fixtures_trial"))
    ap.add_argument("--url", default=None)
    ap.add_argument("--out", default=os.path.join(HERE, "trial_out.xlsx"))
    a = ap.parse_args(argv)

    t0 = time.time()
    if a.url:
        # 真实站点：列表页走网络，详情页同样走网络；1 秒 1 次，只碰公开页
        base = a.url
        fetcher = _live_fetch
        list_html = _live_fetch(base)
        crawler.FETCH = fetcher
        pages = [(base, list_html)]
        delay = 1.0
    else:
        list_html = open(os.path.join(a.dir, "list.html"), encoding="utf-8").read()
        crawler.FETCH = crawler.local_fetch(a.dir)
        pages = [("file:///list.html", list_html)]
        delay = 0

    records, stats, failures = crawler.crawl(pages, delay=delay, retries=3)
    xlsx = crawler.store_xlsx(a.out, records, failures, stats)
    elapsed = round(time.time() - t0, 2)

    fr = stats["fill_rate"]
    low = [k for k, v in fr.items() if v < 0.6]
    print()
    print("VERDICT 1 / 规模：列表页 1 个 → 详情 %d 个 → 入库 %d 条，判重 %d，失败 %d"
          % (stats["details"], len(records), stats["dup"], len(failures)))
    print("VERDICT 2 / 质量：字段填充率 %s%s"
          % (", ".join("%s %.2f" % (k, v) for k, v in fr.items()),
             ("；偏低：" + ",".join(low)) if low else ""))
    print("VERDICT 3 / 速度：%s 秒，台账 %s（三页：tenders / failed / fill_rate）"
          % (elapsed, xlsx))
    print()
    for r in records:
        print("  %-10s %-30s %-8s %s" % (r.get("notice_type") or "-",
                                         (r.get("title") or "-")[:28],
                                         r.get("budget_yuan") or "-",
                                         (r.get("deadline") or "-")[:10]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
