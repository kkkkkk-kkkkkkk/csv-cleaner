#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成 12 条详情页的试单站点（比 demo 的 4 条更像真实列表页）。

刻意埋了三种真实情况：预算缺失、发布时间缺失、同标的重复公告（应被判重），
外加一个 404 详情页（应进 failed 页而不是让整批崩掉）。
"""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "fixtures_trial")

ROWS = [
    ("某市政务云平台运维服务项目（二次）招标公告", "公开招标", "某市政务云平台运维服务项目",
     "某市大数据管理局", "128.50万元", "广东省 阳江市", "2026-12-08 09:30", "2026-11-20"),
    ("县域医共体信息化建设项目招标公告", "公开招标", "县域医共体信息化建设项目",
     "某县卫生健康局", "46万元", "广东省 清远市", "2026-12-02 10:00", "2026-11-19"),
    ("某学校食堂食材配送项目招标公告", "竞争性磋商", "某学校食堂食材配送项目",
     "某实验中学", "38.60万元", "广东省 阳江市", "2026-11-30 17:00", "2026-11-21"),
    ("城市道路照明节能改造工程", "公开招标", "城市道路照明节能改造工程",
     "某市城市管理局", "215万元", "广东省 佛山市", "2026-12-15 09:30", "2026-11-18"),
    ("污水处理厂提标改造设备采购", "公开招标", "污水处理厂提标改造设备采购",
     "某县水务集团", "88.00万元", "广东省 湛江市", "2026-12-11 14:30", "2026-11-17"),
    ("中小学校园安防监控升级项目", "公开招标", "中小学校园安防监控升级项目",
     "某区教育局", "73.20万元", "广东省 广州市", "2026-12-05 09:00", "2026-11-16"),
    ("档案馆数字化加工服务采购", "单一来源", "档案馆数字化加工服务采购",
     "某市档案馆", "29.80万元", "广东省 珠海市", "2026-12-03 10:30", "2026-11-22"),
    ("工业园区污水在线监测运维", "公开招标", "工业园区污水在线监测运维",
     "某工业园区管委会", "52.00万元", "广东省 惠州市", "2026-12-09 15:00", "2026-11-20"),
    # 预算缺失：只有截止时间，没有预算
    ("某医院后勤保洁服务外包", "竞争性磋商", "某医院后勤保洁服务外包",
     "某市人民医院", None, "广东省 汕头市", "2026-12-04 09:30", "2026-11-23"),
    # 发布时间缺失
    ("某镇农贸市场改造工程", "公开招标", "某镇农贸市场改造工程",
     "某镇人民政府", "61.50万元", "广东省 茂名市", None, None),
    # 同标的重复公告（标题/采购人/预算与第 2 条一致，应判重）
    ("县域医共体信息化建设项目招标公告", "公开招标", "县域医共体信息化建设项目",
     "某县卫生健康局", "46万元", "广东省 清远市", "2026-12-02 10:00", "2026-11-25"),
]


def page(title, notice_type, project, buyer, budget, region, deadline, publish):
    ps = ["<h1>%s</h1>" % title, "<p>公告类型：%s</p>" % notice_type,
          "<p>项目名称：%s</p>" % project, "<p>采购人：%s</p>" % buyer]
    if budget:
        ps.append("<p>预算金额：%s</p>" % budget)
    ps.append("<p>项目所在地：%s</p>" % region)
    if deadline:
        ps.append("<p>投标截止时间：%s</p>" % deadline)
    if publish:
        ps.append("<p>发布时间：%s</p>" % publish)
    ps.append("<p>本项目按公开程序组织，欢迎符合条件的供应商参与。</p>")
    return ("<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\"><title>%s</title></head>\n"
            "<body><div class=\"content\">\n%s\n</div></body></html>\n"
            % (title, "\n".join("  " + x for x in ps)))


def main():
    os.makedirs(OUT, exist_ok=True)
    items = []
    for i, row in enumerate(ROWS, 1):
        name = "d%02d.html" % i
        with open(os.path.join(OUT, name), "w", encoding="utf-8") as fh:
            fh.write(page(*row))
        items.append('<li><a href="/tender/%s">%s</a></li>' % (name, row[0]))
    # 404 详情页：让 failed 页有内容，证明单条失败不会拖垮整批
    items.append('<li><a href="/tender/d99_missing.html">某项目（已下线）</a></li>')
    # 列表页自身的重复链接，证明链接级去重
    items.append('<li><a href="/tender/d01.html">同一条（重复链接）</a></li>')
    items.append('<li><a href="/about.html">关于本站</a></li>')
    with open(os.path.join(OUT, "list.html"), "w", encoding="utf-8") as fh:
        fh.write("<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\">"
                 "<title>招标公告列表 · 试单站点</title></head>\n<body>\n"
                 "<h1>公开招标公告列表</h1>\n<ul class=\"list\">\n%s\n</ul>\n"
                 "</body></html>\n" % "\n".join("  " + x for x in items))
    print("fixtures_trial: %d detail pages + list.html" % len(ROWS))


if __name__ == "__main__":
    main()
