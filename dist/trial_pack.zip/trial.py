# -*- coding: utf-8 -*-
"""Trial pack — one command, one auditable workbook.

    python trial.py                 # run on the bundled sample (268 valid rows)
    python trial.py your.csv        # run on the client's own file

Output: trial_out.xlsx (6 sheets) + trial_out.json (summary snapshot) + 3-line verdict.
Requires: Python 3.8+, openpyxl.  Nothing else.
"""
import os, sys, json, time, io, re, contextlib

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import report  # noqa: E402

src = sys.argv[1] if len(sys.argv) > 1 else "sample_sales.csv"
if not os.path.isabs(src):
    src = os.path.join(HERE, src)
out = os.path.join(HERE, "trial_out.xlsx")
snap = os.path.join(HERE, "trial_out.json")

t0 = time.time()
sys.argv = ["report.py", src, out, "--json", snap]
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    report.main()
txt = buf.getvalue()
elapsed = time.time() - t0
print(txt)

with open(snap, encoding="utf-8") as f:
    j = json.load(f)
m = re.search(r"有效金额\s+([\d.]+)\s+有效数量\s+(\d+)", txt)
amt, qty = (float(m.group(1)), int(m.group(2))) if m else (j["tot_amount"], 0)
m2 = re.search(r"原始行\s+(\d+)", txt)
raw = int(m2.group(1)) if m2 else j["rows"] + j["dropped"]

print("\n" + "=" * 62)
print("VERDICT  (what a client reads first)")
print("=" * 62)
print("1. Rows:      {rows} valid of {raw} raw  ({dropped} dropped, every one listed in 明细)".format(
    rows=j["rows"], raw=raw, dropped=j["dropped"]))
print("2. Total:     {amt:,.2f}  qty {qty}".format(amt=amt, qty=qty))
print("3. Self-check: sheet 核对 has 7 formulas the workbook computes itself;")
print("   it reads PASS only when every diff is 0.000 — no number is typed in by hand.")
print("   Elapsed {:.2f}s on {} rows.".format(elapsed, j["rows"]))
print("=" * 62)
