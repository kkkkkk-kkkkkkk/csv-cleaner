# Invoice PDF extraction — trial pack

Five Chinese VAT invoices in, one auditable workbook out. **One command, about one second.**

```bash
unzip pdf_trial_pack.zip && cd pdf_trial_pack
python trial.py
```

No dependencies beyond `openpyxl` and `PyMuPDF`.

## What it does

| Step | What happens |
|---|---|
| 1 | Reads every `*.pdf` in `fixtures/` (text layer only — no OCR, no cloud API) |
| 2 | Extracts 8 fields per invoice: invoice no, date, seller, buyer, amount, tax, total, items |
| 3 | Runs 5 checks: amount + tax = total (tolerance 0.02), duplicate invoice numbers, missing fields, date sanity, negative values |
| 4 | Writes `trial_out.xlsx` — ledger page, review page, stats page |
| 5 | Prints three `VERDICT` lines to the terminal |

Reference run on the bundled five invoices:

```
VERDICT 1 / 5 PDFs -> 5 rows, 2 passed, 3 need review
VERDICT 2 / 4 issues (all high severity), each with field name and reason on the review page
VERDICT 3 / amount 5,300.00, total 5,999.00, 1.30 s
```

Bring your own files: `python trial.py --dir /path/to/your/pdfs`.

## Three rules I hold to

1. **A field I cannot read is marked "needs review", never filled with 0.** A zero silently drags the total down; a flag makes a human look.
2. **The totals are checked, not assumed.** `amount + tax = total` is verified per row; rows that fail are listed, not "fixed".
3. **Read-only.** The source PDFs are opened, never rewritten.

## Sizing

Under 200 pages runs in seconds on a laptop. Above that, tell me the page count and whether the PDFs have a text layer (scans need OCR, which is a different, slower job).

