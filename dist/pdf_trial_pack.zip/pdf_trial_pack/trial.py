#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""trial.py — 一条命令跑完发票 PDF 抽取（3 秒内出结果）

    python trial.py                  # 用自带 5 张样例发票
    python trial.py --dir your_pdfs  # 用你自己的 PDF 目录

输出：trial_out.xlsx（台账页 + 复核页 + 统计页），并在终端打印三行 VERDICT。
"""
import os, sys, glob, time, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import invoice_extract as ix


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default=os.path.join(HERE, "fixtures"))
    ap.add_argument("--out", default=os.path.join(HERE, "trial_out.xlsx"))
    a = ap.parse_args(argv)

    d = os.path.abspath(a.dir)
    paths = sorted(glob.glob(os.path.join(d, "*.pdf")))
    if not paths:
        print("没有 PDF 可读：%s" % d)
        return 1

    t0 = time.time()
    rows, issues, stats = ix.extract_batch(paths)
    ix.store_xlsx(a.out, rows, issues, stats)
    total = time.time() - t0

    print("")
    print("VERDICT 1 / 文件：%d 张 PDF → %d 行台账，通过 %d、需复核 %d"
          % (stats["files"], len(rows), stats["passed"], stats["flagged"]))
    print("VERDICT 2 / 校验：问题 %d 条（其中高危 %d），全部列在「复核」页，逐条给了字段名与原因"
          % (stats["issues"], stats["issue_high"]))
    print("VERDICT 3 / 数字：金额合计 %.2f，价税合计 %.2f，耗时 %.2f 秒"
          % (stats["amount_sum"], stats["total_sum"], total))
    print("")
    print("台账：%s" % a.out)
    print("说明：不猜字段、不改原文件、读不出就记「需复核」而不是填 0。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
